# RealTimeWeb applications

Instructions are given on the webpage, but basically your goal is to collect as many minerals as you can. Note that other players can snatch them away from the planet before you though!

To start:
1) npm install
2) node app.js

Known "issues":
- If searching for minerals on a planet with a placed flag, the first search action will not yield double the amount.
- Users always join the Earth chat initially, even if they last saved from another planet (which is fine though, as Earth can be considered the central spawn hub)

To do:
- Clean up code (there are some needless doubles in there, no large issue since the game is small)
