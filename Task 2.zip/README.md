# RealTimeWeb application

Instructions are given on the webpage, but basically your goal is to collect as many minerals as you can. Note that other players can snatch them away from you though!

To start:
npm install
node app.js

I tried to figure out the mongoDB things, got it to work locally on some test files - but since I have no idea how to transport the data on there (unlike the .JSON files, which can just be transferred), this task still uses JSON.

Known issues:
- If searching for minerals on a planet with a placed flag, the first search action will not yield double the amount.
-
